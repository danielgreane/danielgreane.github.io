inlets = 1;
outlets = 1;
var e = new Dict("exposedParams");

function addParamInfo(paramArgs)
{
	var paramId = paramArgs[0];
	var paramName = paramArgs[1];
	var paramMin = paramArgs[2];
	var paramMax = paramArgs[3];
	var type = "float";
	var path = paramArgs[5];
	var address = "/midiCC/ "+paramId;

	var paramString = "id: "+paramId;
	paramString = paramString+' name: "'+paramName+'"';
	paramString = paramString+" min: "+paramMin;
	paramString = paramString+" max: "+paramMax;
	paramString = paramString+" type: "+type;
	paramString = paramString+' path: "'+path+'"';
	paramString = paramString+" address: "+address;

	var size = e.getsize("exposedParams");
	var nextPos = "exposedParams["+size+"]"
	e.append("exposedParams", ""); // this is a crucial step - this turns features' value into an empty array
	e.setparse(nextPos, paramString);

	outlet(0, "finished");
}


function addMidiTrack(midiTrackArgs)
{
	var id = midiTrackArgs[0];
	var name = midiTrackArgs[1];
	var path = midiTrackArgs[2];
	var address = "/liveMidi/ "+id;

	var trackString = "id: "+id;
	trackString = trackString+' name: "'+name+'"';
	trackString = trackString+' path: "'+path+'"';
	trackString = trackString+" address: "+address;

	// post("trackString = "+trackString+"\n");

	var size = e.getsize("midiTracks");
	var nextPos = "midiTracks["+size+"]"
	e.append("midiTracks", "");
	e.setparse(nextPos, trackString);

	outlet(0, "finished");
}

function list()
{
	var a = arrayfromargs(arguments);
	//post("received list " + a + "\n");
	if (a[1] == "info")
	{
		a.splice(1, 1);
		addParamInfo(a);
	}
	else if (a[1] == "midiTrack")
	{
		a.splice(1, 1);
		addMidiTrack(a);
	}

	bang();
}

function clearParams() { 
	e.set("exposedParams", "");

	outlet(0, "finished");
}

function clearMidiTracks() { 
	e.set("midiTracks", "");

	outlet(0, "finished");
}

function bang() { 
}
